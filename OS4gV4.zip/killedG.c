//
// Created by Gal on 10/06/2018.
//

#include <stdio.h>
#include <stdlib.h>
#include <linux/types.h>
#include <unistd.h>
#include <errno.h>

int main() {
    sleep(3);
    return 0;
}
